const API_BASE_URL = "http://localhost:8080";

let currentPage = 1; // Keep track of the current page

// Function to fetch and display products
async function fetchAndDisplayProducts() {
  const collection = document.getElementById("collection-select").value; // Selected collection
  const filter = document.getElementById("filter-input").value; // Filter by name
  const sort = document.getElementById("sort-select").value; // Sort field

  try {
    const response = await fetch(
      `${API_BASE_URL}/${collection}?filter=${filter}&sort=${sort}&page=${currentPage}`
    );
    if (!response.ok) throw new Error("Failed to fetch products");

    const data = await response.json();
    displayProducts(data); // Render the products in UI
    updatePaginationControls(); // Update pagination controls
  } catch (error) {
    console.error("Error fetching products:", error);
    displayError("No products found or error occurred.");
  }
}

// Function to display products in the UI
function displayProducts(products) {
  const productsContainer = document.getElementById("products-container");
  productsContainer.innerHTML = ""; // Clear old products

  if (products.length === 0) {
    displayError("No products found.");
    return;
  }

  products.forEach((product) => {
    const productCard = document.createElement("div");
    productCard.className = "product-card";
    productCard.innerHTML = `
      <h3>${product.name}</h3>
      <p>Price: $${product.price}</p>
      <p><strong>Brand:</strong> ${product.brand || "N/A"}</p>
      <p><strong>Stock:</strong> ${product.stock || "N/A"}</p>
      <p><strong>Category:</strong> ${product.category || "N/A"}</p>
      <p><strong>Description:</strong> ${product.description || "N/A"}</p>
    `;
    productsContainer.appendChild(productCard);
  });
}

// Function to display an error message
function displayError(message) {
  const productsContainer = document.getElementById("products-container");
  productsContainer.innerHTML = `<p class="error">${message}</p>`;
}

// Function to update pagination controls
function updatePaginationControls() {
  const currentPageElement = document.getElementById("current-page");
  currentPageElement.textContent = `Page ${currentPage}`;
}

// Event listeners for pagination buttons
document.getElementById("prev-page-btn").addEventListener("click", () => {
  if (currentPage > 1) {
    currentPage--;
    fetchAndDisplayProducts();
  }
});

document.getElementById("next-page-btn").addEventListener("click", () => {
  currentPage++;
  fetchAndDisplayProducts();
});

// Initial fetch when page loads
document.getElementById("search-btn").addEventListener("click", () => {
  currentPage = 1; // Reset to the first page
  fetchAndDisplayProducts();
});

document.getElementById('emailForm').addEventListener('submit', async function (e) {
  e.preventDefault();

  const to = document.getElementById('emailTo').value;
  const subject = document.getElementById('emailSubject').value;
  const message = document.getElementById('emailMessage').value;

  const emailData = {
      to: to,
      subject: subject,
      message: message,
  };

  try {
      const response = await fetch('http://localhost:8080/admin/send-email', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify(emailData),
      });

      if (!response.ok) {
          throw new Error(`Error: ${response.status} - ${response.statusText}`);
      }

      const result = await response.text();
      alert(result); // Display success message
  } catch (error) {
      console.error('Error sending email:', error);
      alert('Failed to send email. Please try again.');
  }
});
