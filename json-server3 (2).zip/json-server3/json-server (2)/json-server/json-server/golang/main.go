package main

import (
	"context"
	"encoding/json"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"syscall"
	"time"

	"github.com/gorilla/mux"
	"github.com/ulule/limiter/v3"
	"github.com/ulule/limiter/v3/drivers/store/memory"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"go.uber.org/zap"
)

var (
	client *mongo.Client
	logger *zap.Logger
)

func init() {
	// Initialize logger
	var err error
	logger, err = zap.NewProduction()
	if err != nil {
		log.Fatalf("Failed to initialize logger: %v", err)
	}

	// Connect to MongoDB
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	client, err = mongo.Connect(ctx, options.Client().ApplyURI("mongodb://localhost:27017"))
	if err != nil {
		logger.Fatal("Failed to connect to MongoDB", zap.Error(err))
	}
}

func corsMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
		if r.Method == "OPTIONS" {
			return
		}
		next.ServeHTTP(w, r)
	})
}

func errorHandlerMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if err := recover(); err != nil {
				http.Error(w, "Internal Server Error", http.StatusInternalServerError)
				logger.Error("Recovered from panic", zap.Any("error", err))
			}
		}()
		next.ServeHTTP(w, r)
	})
}

func rateLimitMiddleware() mux.MiddlewareFunc {
	store := memory.NewStore()
	rate := limiter.Rate{Period: time.Minute, Limit: 10} // 10 requests per minute
	instance := limiter.New(store, rate)

	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			ctx, err := instance.Get(r.Context(), r.RemoteAddr)
			if err != nil {
				http.Error(w, "Rate limiting error", http.StatusInternalServerError)
				return
			}
			if ctx.Reached {
				http.Error(w, "Rate limit exceeded", http.StatusTooManyRequests)
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}

func getProducts(w http.ResponseWriter, r *http.Request) {
	collectionName := mux.Vars(r)["collection"]
	collection := client.Database("sports_supplements").Collection(collectionName)

	// Query parameters
	filter := r.URL.Query().Get("filter")
	sort := r.URL.Query().Get("sort")
	pageStr := r.URL.Query().Get("page")
	page, err := strconv.Atoi(pageStr)
	if err != nil || page < 1 {
		page = 1
	}

	limit := 7
	offset := (page - 1) * limit

	// MongoDB filters and options
	filterQuery := bson.M{}
	if filter != "" {
		filterQuery["name"] = bson.M{"$regex": filter, "$options": "i"}
	}

	sortQuery := bson.D{}
	if sort != "" {
		sortQuery = bson.D{{Key: sort, Value: 1}} // Ascending order
	}

	findOptions := options.Find().SetSort(sortQuery).SetLimit(int64(limit)).SetSkip(int64(offset))

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	cursor, err := collection.Find(ctx, filterQuery, findOptions)
	if err != nil {
		http.Error(w, "Failed to retrieve products", http.StatusInternalServerError)
		logger.Error("Error fetching products", zap.Error(err))
		return
	}
	defer cursor.Close(ctx)

	var products []bson.M
	if err = cursor.All(ctx, &products); err != nil {
		http.Error(w, "Error parsing products", http.StatusInternalServerError)
		logger.Error("Error parsing products", zap.Error(err))
		return
	}

	if len(products) == 0 {
		http.Error(w, "No products match the filter", http.StatusNotFound)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(products)
}

func sendEmail(w http.ResponseWriter, r *http.Request) {
	var request struct {
		To      string `json:"to"`
		Subject string `json:"subject"`
		Body    string `json:"body"`
	}

	if err := json.NewDecoder(r.Body).Decode(&request); err != nil {
		http.Error(w, "Invalid request body", http.StatusBadRequest)
		logger.Error("Invalid request body", zap.Error(err))
		return
	}

	// Simulate email sending (replace with actual email logic as needed)
	logger.Info("Email sent", zap.String("to", request.To), zap.String("subject", request.Subject))
	w.WriteHeader(http.StatusOK)
	w.Write([]byte("Email sent successfully"))
}

func main() {
	r := mux.NewRouter()

	// Apply middlewares
	r.Use(corsMiddleware)
	r.Use(errorHandlerMiddleware)
	r.Use(rateLimitMiddleware())

	// Routes
	r.HandleFunc("/{collection}", getProducts).Methods("GET")
	r.HandleFunc("/admin/send-email", sendEmail).Methods("POST")

	// Server configuration
	server := &http.Server{
		Handler:      r,
		Addr:         ":8080",
		WriteTimeout: 15 * time.Second,
		ReadTimeout:  15 * time.Second,
	}

	// Graceful shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt, syscall.SIGTERM)

	go func() {
		<-quit
		logger.Info("Shutting down server...")
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := server.Shutdown(ctx); err != nil {
			logger.Fatal("Server forced to shutdown", zap.Error(err))
		}
	}()

	logger.Info("Server is running", zap.String("port", ":8080"))
	if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		logger.Fatal("Server error", zap.Error(err))
	}

	logger.Info("Server exited.")
}
